<?php
return [
    'domain' => 'yun8.pagepan.com',
    'version' => ''
];