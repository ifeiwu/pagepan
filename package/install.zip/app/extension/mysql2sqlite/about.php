<?php
return [
    'title' => 'MySQL 迁移至 SQLite',
    'description' => '根据业务需求，我们提供该工具，用于实现网站 MySQL 迁移数据至 SQLite。',
    'version' => '1.0',
    'author_name' => 'M',
    'author_url' => ''
];