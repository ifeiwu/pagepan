<?php
return function () {
    $view = view();
    $view->display('extension/webroot2public/main');
};