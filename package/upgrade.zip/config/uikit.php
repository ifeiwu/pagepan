<?php
return [
    'cache' => true,
    'uri' => 'https://uikit8.pagepan.com/'
];