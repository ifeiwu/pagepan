<?php
return [
    'title' => 'WEB根目录转Public',
    'description' => '将 WEB 服务器的根目录设置为 Public 目录可以有效隐藏应用的内部结构和敏感文件。',
    'version' => '1.0',
    'author_name' => 'M',
    'author_url' => ''
];