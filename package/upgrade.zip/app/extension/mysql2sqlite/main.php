<?php
return function () {
    $view = view();
    $view->display('extension/mysql2sqlite/main');
};