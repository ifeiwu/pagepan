<?php
// 发送邮件
return function ($title, $content, $_config = []) {

	$config = Config::get('smtp');

	if ( ! is_array($config) ) {
	    return false;
	}
	
	$config = array_merge($config, $_config);
	$mailer = new \Mailer($config);
	$mailer->setTitle($title);
	$mailer->setContent($content);
	$mailer->addAddress($config['address']);
	
	return $mailer->send();
};