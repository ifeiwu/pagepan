<?php
// 是否手机或平板设备
return function ($detect = null) {
//	$md = new Detection\MobileDetect();
//
//	if ( $detect == 'phone' ) {
//		return $detect->isMobile() && ! $detect->isTablet(); // 手机
//	} elseif ( $detect == 'tablet' ) {
//		return $md->isTablet(); // 平板
//	} else {
//		return $md->isMobile(); // 手机或平板
//	}
};