<?php
// 接口请求
return function ($url, $data = [], $token = '') {

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ));

    $response = curl_exec($ch);

    if ( $response === false )
    {
        $error = curl_error($ch);
        $code = curl_errno($ch);

        return ['code' => 1, 'message' => "Api($url): $error ($code)", 'data' => []];
    }

    curl_close($ch);

    return json_decode($response, true);
};