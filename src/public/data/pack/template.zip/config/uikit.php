<?php
return [
    'cache' => true,
    'cdn.uri' => 'https://cdn.pagepan.com/',
    'cdn.token' => '',
    'uri' => 'https://uikit.pagepan.com/',
    'user' => '',
    'pass' => '',
];