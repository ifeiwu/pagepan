<?php
return [
    'debug' => false,
    'type' => 'sqlite',
    'file' => 'data/sqlite/pagepan-dev.db',
    'prefix' => ''
];