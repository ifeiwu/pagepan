<?php
return [
    'cache' => false,
    'cdn.uri' => 'http://192.168.31.5:8089/',
    'cdn.token' => '',
    'uri' => 'http://192.168.31.5:8087/',
    'user' => '',
    'pass' => '',
];