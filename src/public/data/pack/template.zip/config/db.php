<?php
return [
    'debug' => false,
    'type' => 'sqlite',
    'file' => 'data/sqlite/pagepan.db',
    'prefix' => ''
];