<?php
/**
require ROOT_PATH . 'plugin/Plugin1.php';
$system = new System();
$plugin = new Plugin1();

$system->attach($plugin);

$system->setState(1);
$system->setState(2);
$system->setState(3);

$system->detach($plugin);

$system->setState(4);
 */
class System implements SplSubject
{
    private $observers;

    private $state;

    public function __construct()
    {
        $this->observers = new SplObjectStorage();
        $this->state = 0;
    }

    public function attach(SplObserver $observer)
    {
        $this->observers->attach($observer);
    }

    public function detach(SplObserver $observer)
    {
        $this->observers->detach($observer);
    }

    public function notify()
    {
        foreach ($this->observers as $observer) {
            $observer->update($this);
        }
    }

    public function setState($state)
    {
        $this->state = $state;
        $this->notify();
    }

    public function getState()
    {
        return $this->state;
    }
}