<?php

class Plugin1 implements SplObserver
{
    public function update(SplSubject $subject)
    {
        echo "Plugin: State changed to " . $subject->getState() . PHP_EOL;
    }
}