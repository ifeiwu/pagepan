<?php $this->start() ?>
    <section class="h-screen">
        <div class="container-fluid h-full">
            <div class="flex justify-center items-center h-full center">
                <div>
                    <h1 style="font-size: 10rem">404</h1>
                    <p class="mb-10">很抱歉！您访问的页面已无法打开。</p>
                    <a href="<?=$this->url(''); ?>" class="btn btn-sm btn-primary r-full">回到首页</a>
                </div>
            </div>
        </div>
    </section>
<?php $this->stop() ?>