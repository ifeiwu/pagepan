<!-- http://site.pagepan.loc:8088/m/dev/a/rec?isbuilder=0&theme=0&path=number/d1/01 -->
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>视频录制</title>
    <link href="/assets/css/pagepan.css" rel="stylesheet">
    <style>
        html, body {
            font-family: ABeeZee, AlibabaPuHui;
        }
        .sizes {
            outline: 0;
            cursor: pointer;
            border: 2px solid transparent;
            padding: 3px 40px 3px 10px;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='24' height='24'%3E%3Cpath fill='none' d='M0 0h24v24H0z'/%3E%3Cpath d='M12 13.172l4.95-4.95 1.414 1.414L12 16 5.636 9.636 7.05 8.222z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: 95% center;
            background-size: 20px;
            -webkit-appearance: none;
        }

        .sizes:focus {
            border-color: #ddd;
        }

        .options li {
            display: block;
            font-size: 16px;
            background-color: var(--mix-37)
        }

        .options li.active,
        .options li:hover {
            color: #fff;
            background-color: #111;
        }
    </style>
</head>
<body>

    <div class="container-fluid h-full">
        <div class="flex items-center h-full p-10">
            <div>
                <div class="flex flex-col" style="width:1600px;height:900px">
                    <header class="flex items-center justify-between px-8 py-4" style="--bgc:#f5f5f5">
                        <div>
                            <div class="flex">
                                <div class="h-5 w-5 r-full mr-3" style="--bgc:#fc625d"></div>
                                <div class="h-5 w-5 r-full mr-3" style="--bgc:#fec041"></div>
                                <div class="h-5 w-5 r-full" style="--bgc:#35ca4a"></div>
                            </div>
                        </div>
                        <div>
                            <span class="f-5 px-4"><?=$_GET['path']; ?></span>
                        </div>
                        <div>
                            <select class="sizes bg-transparent f-6 r-2">
                                <option value="1600">Desktop - 1600</option>
                            </select>
                        </div>
                    </header>
                    <section class="h-full" style="border: 1px solid #f5f5f5;border-top: none;">
                        <iframe src="<?="/dev/uikit?isbuilder={$_GET['isbuilder']}&theme={$_GET['theme']}&path={$_GET['path']}"; ?>" id="viewport" width="100%" height="100%" frameborder="0" scrolling="no" allowtrancparency="true"></iframe>
                    </section>
                </div>
            </div>
            <div class="flex-grow-1">
                <div class="pl-15">
                    <h6 class="f-6 mb-6">自动播放</h6>
                    <ul class="flex flex-col gap-1 options">
                        <?php
                        $active = 1;
                        $options = ['2 秒','3 秒','4 秒','5 秒'];
                        foreach ($options as $i => $value):
                        ?>
                        <li class="btn btn-2 r-2 <?=$i == $active ? 'active' : ''; ?>"><?=$value; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
