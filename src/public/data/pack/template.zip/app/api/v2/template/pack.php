<?php
// 打包模板
return function ($request_data) {
    $zip_path = WEB_DATA . 'pack/';
    $zip_name = 'template.zip';
    $zip_file = $zip_path . $zip_name;

    if ( ! FS::rmkdir($zip_path) ) {
        Response::error('创建目录失败：' . $zip_path);
    }

    try {
        loader_vendor();
        $zipFile = new \PhpZip\ZipFile();
        $finder = (new \Symfony\Component\Finder\Finder())
            ->exclude('.git')
//            ->exclude('vendor')
            ->exclude('data/backup')
            ->exclude('data/logs')
            ->exclude('data/cache')
            ->exclude('public/data/pack')
            ->notPath('install.lock')
            ->notPath('config/apikey.php')
            ->in(ROOT_PATH);

        $zipFile->addFromFinder($finder);
        $zipFile->saveAsFile($zip_file);
        $count = $zipFile->count();
        $zipFile->close();

        if ( $count > 0 ) {
            Response::success();
        } else {
            Response::error('压缩文件出错：' . $zip_file);
        }
    } catch(\PhpZip\Exception\ZipException $e) {
        Response::error($e->getMessage());
    }
};