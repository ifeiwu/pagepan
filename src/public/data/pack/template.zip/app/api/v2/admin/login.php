<?php
return function () {
    echo '----------';
};