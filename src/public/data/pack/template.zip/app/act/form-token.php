<?php
/**
 * 生成表单令牌
 */
return function () {
	
	exit(helper('form/token'));
};